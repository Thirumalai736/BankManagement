package com.wipro.bank.acc;

public  class RDAccount extends Account{
  public RDAccount(int tenure,float principle) {
	  this.tenure=tenure;
	  this.principle=principle;
	  
  }
  @Override
  public float calculateAmountDeposited() {
	  
	  return principle*tenure*12;
  }
  @Override
  public float calculateIntrest() {
      float total = calculateAmountDeposited();

      return (float) (total *Math.pow(1+ (rateOfIntrest / 100)/4,4*tenure)-total);
  }
  }
