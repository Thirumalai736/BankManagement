package com.wipro.bank.acc;

public abstract class Account {
  int tenure;
  float principle;
  float rateOfIntrest;
  

  public void setIntrest(int age , String gender) {
	  if(gender.equalsIgnoreCase("Male") && age <60) {
		  rateOfIntrest=9.8f;
	  }else if(gender.equalsIgnoreCase("Male") && age >=60) {
		  rateOfIntrest=10.5f;
	  }else if(gender.equalsIgnoreCase("Female") && age <58) {
		  rateOfIntrest=10.2f;
	  }else if(gender.equalsIgnoreCase("Female") && age >=58) {
		  rateOfIntrest=10.8f;
	  }
  }
  public float getRateOfIntrest() {
	return rateOfIntrest;
}


  public float calculateMaturityAmount(float totalPrincipleDeposited,float maturityIntrest) {
	
	  return totalPrincipleDeposited+maturityIntrest;
  }
  public abstract float calculateIntrest();
  
  public abstract float calculateAmountDeposited();
  

  
 }
