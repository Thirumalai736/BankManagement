package com.wipro.bank.exception;


public class BankValidationExecption extends Exception{

	@Override
	public String toString() {
		return "invalid data";
	}

}
