package com.wipro.bank.service;

import com.wipro.bank.acc.RDAccount;
import com.wipro.bank.exception.BankValidationExecption;

public class BankService {

public  boolean validData(float principle,int tenure,int age,String gender){
		
try {
	if(principle>=500) {
		if(tenure==5 || tenure==10) {
			if(gender.equalsIgnoreCase("male") || gender.equalsIgnoreCase("female")) {
				if(age>=1 && age<=100) {
					return true;
	}}}}else {
		throw new BankValidationExecption ();
	}
}catch(BankValidationExecption e){
	return false;
}

	return false;
}
public void calculate(float principal, int tenure, int age, String gender) {

    if (validData(principal, tenure, age, gender)) {

        RDAccount rd = new RDAccount(tenure, principal);

        rd.setIntrest(age, gender);

        float deposited = rd.calculateAmountDeposited();

        float interest = rd.calculateIntrest();

        float maturity = rd.calculateMaturityAmount(deposited, interest);

        System.out.println("Rate of Interest:"+rd.getRateOfIntrest());

        System.out.println("Total Deposited:"+deposited);

        System.out.println("Interest:"+interest);

        System.out.println("Maturity Amount:"+maturity);
    }
    else {
        System.out.println("Invalid Input");
    }
}
}
