package com.wipro.bank.main;

import java.util.Scanner;

import com.wipro.bank.service.BankService;

public class Main {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Tenure either 5 or 10:");
	int tenure=sc.nextInt();
	System.out.println("Enter Principle Amoouunt 500 or above:");
	float principle=sc.nextFloat();
	System.out.println("Enter age:");
	int age=sc.nextInt();
	System.out.println("Enter gender:");
	sc.nextLine();
	String gender=sc.nextLine();
	
	


BankService bs = new BankService();
bs.calculate(principle, tenure, age, gender);
	
	sc.close();
}
}
